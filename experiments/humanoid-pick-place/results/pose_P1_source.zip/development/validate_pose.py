import base64,hashlib,json
from pathlib import Path
import numpy as np
from humanoid_sim.environment import Environment
from humanoid_sim.visual import RGBRenderer,VisualSession,integration_state,detect_red_pixels,pixel_to_plane
from humanoid_sim.vision_pose import estimate_supported_block
root=Path('runtime/humanoid/pose-P1');root.mkdir(exist_ok=False)
paths=[*Path('humanoid_sim').glob('*.py'),Path('scenes/g1_pick_place.xml'),Path('experiments/humanoid-pick-place/protocols/P1.md')]
frozen={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(root/'manifest.json').write_text(json.dumps({'seeds':list(range(720,740)),'source_sha256':frozen},indent=2)+'\n')
env=Environment();renderer=RGBRenderer(env);records=[]
try:
 for seed in range(720,740):
  assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in frozen.items())
  env.reset(seed,True);before=integration_state(env);o=VisualSession(env,renderer).capture()
  np.testing.assert_array_equal(integration_state(env),before)
  png=base64.b64decode(o['rgb_png_base64']);(root/f'seed-{seed}.png').write_bytes(png)
  estimate=estimate_supported_block(png,o['camera']);old=detect_red_pixels(png)
  truth=env.data.xpos[env.object_id].copy()
  old_xyz=pixel_to_plane(old['centroid_xy_px'],.82,o['camera']) if old['detected'] else None
  error=float(np.linalg.norm(np.asarray(estimate['object_center_xyz_m'][:2])-truth[:2])) if estimate['detected'] else None
  record={'seed':seed,'estimate':estimate,'xy_error_m':error,'within_5mm':error is not None and error<=.005,
          'old_centroid_xy_error_m':float(np.linalg.norm(np.asarray(old_xyz[:2])-truth[:2])) if old_xyz else None,
          'private_true_center_xyz':truth.tolist(),'state_preserved':True}
  records.append(record)
  summary={'development_only':True,'status':'complete' if len(records)==20 else 'running','records':records,'source_sha256':frozen}
  (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  print(json.dumps({'seed':seed,'accepted':estimate['detected'],'xy_error_m':error,'reason':estimate.get('reason')}),flush=True)
finally:renderer.close()

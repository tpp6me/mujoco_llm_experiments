import base64,json
from pathlib import Path
import numpy as np
from humanoid_sim.environment import Environment
from humanoid_sim.interface import PolicyInterface
from humanoid_sim.visual import RGBRenderer,VisualSession
from humanoid_sim.guarded_baseline import run_policy
from humanoid_sim.vision_pose import estimate_supported_block
root=Path('runtime/humanoid/carried-development');root.mkdir(exist_ok=False)
env=Environment();renderer=RGBRenderer(env)
try:
 for seed in range(740,743):
  folder=root/f'seed-{seed}';folder.mkdir();env.reset(seed,True)
  class CaptureAPI:
   def __init__(self):self.api=PolicyInterface(env,'exact_state');self.records=[]
   def observe(self):return self.api.observe()
   def capture(self,request=None,response=None):
    o=VisualSession(env,renderer).capture();png=base64.b64decode(o.pop('rgb_png_base64'));idx=len(self.records)
    name=f'{idx:02d}.png';(folder/name).write_bytes(png)
    truth=env.data.xpos[env.object_id].copy()
    estimate=estimate_supported_block(png,o['camera'])
    record={'image':name,'observation':o,'request':request,'status':response and response['status'],'initial_estimate':estimate,'private_truth_xyz':truth.tolist(),'private_rotation':env.data.xmat[env.object_id].reshape(3,3).tolist()}
    self.records.append(record);(folder/'records.json').write_text(json.dumps(self.records,indent=2)+'\n')
   def execute(self,request):
    response=self.api.execute(request);self.capture(request,response);return response
  api=CaptureAPI();api.capture()
  try:failure=run_policy(api,release_z=.88)
  except Exception as e:failure=str(e)
  env.save(folder/'episode');print(json.dumps({'seed':seed,'frames':len(api.records),'failure':failure}),flush=True)
finally:renderer.close()

import json,numpy as np
from pathlib import Path
from humanoid_sim.temporal_pose import CORNERS,fit_window,rotation_vector_matrix,convex_hull
from humanoid_sim.carried_pose import select_hypotheses
cam=json.loads(Path('tests/fixtures/humanoid_rgb/cases.json').read_text())['camera']
camera={'origin':np.array(cam['camera_world_xyz_m']),'rotation':np.array(cam['world_to_camera_rotation']),'focal':np.array(cam['focal_xy_px']),'principal':np.array(cam['principal_xy_px'])}
offset=np.array([-.03,0,-.04]);R=rotation_vector_matrix(np.array([.7,.3,.2]));frames=[]
for hand in [[.24,-.18,.975],[.19,-.36,.975],[.21,-.36,.88]]:
 hand=np.array(hand);world=CORNERS@R.T+hand+offset;q=(world-camera['origin'])@camera['rotation'].T;uv=q[:,:2]/q[:,2,None]*camera['focal']+camera['principal'];poly=convex_hull(uv)
 edges=np.concatenate([a+np.arange(25)[:,None]/25*(b-a) for a,b in zip(poly,np.roll(poly,-1,axis=0))]);points=poly.mean(axis=0)+.5*(edges-poly.mean(axis=0))
 frames.append({'hand':hand,'rotation':np.eye(3),'camera':camera,'points':np.concatenate([edges,points]),'edge_count':len(edges),'time_s':float(len(frames))})
a=fit_window(frames);result=select_hypotheses(a);print(result,'error',np.linalg.norm(np.array(result.get('object_center_xyz_m',[0,0,0]))-(frames[-1]['hand']+offset)),flush=True)
print([(round(item['rms_px'],3),round(np.linalg.norm(np.array(item['center_xyz_m'])-(frames[-1]['hand']+offset))*1000,2)) for item in a[:6]])

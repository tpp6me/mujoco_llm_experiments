import itertools
import numpy as np
from humanoid_sim.carried_pose import convex_hull,rotation_vector_matrix,silhouette_features

def quat(q):
 w,x,y,z=np.asarray(q)/np.linalg.norm(q)
 return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
CORNERS=np.array(list(itertools.product([-1,1],repeat=3)))*[.025,.035,.06]
def residual_frame(p,frame):
 R=frame['R'];center=frame['hand']+R@p[:3];world=CORNERS@(R@rotation_vector_matrix(p[3:])).T+center
 cam=frame['camera'];local=(world-cam['origin'])@cam['rotation'].T;uv=local[:,:2]/np.maximum(local[:,2,None],.01)*cam['focal']+cam['principal']
 poly=convex_hull(uv)
 if len(poly)<3:return np.full(len(frame['points']),1e6)
 d=np.roll(poly,-1,axis=0)-poly;length=np.linalg.norm(d,axis=1);v=frame['points'][:,None,:]-poly
 t=np.clip(np.sum(v*d,axis=2)/length**2,0,1);distance=np.linalg.norm(v-t[:,:,None]*d,axis=2).min(axis=1)
 inside=np.all(d[:,0]*v[:,:,1]-d[:,1]*v[:,:,0]>=0,axis=1);n=frame['edge_count']
 return np.r_[distance[:n],np.where(inside[n:],0,distance[n:])*2]

def prepare(png,o):
 cam=o['camera'];h=o['robot_state']['robot'];edges,points,d= silhouette_features(png,cam)
 if edges is None:return None
 return {'hand':np.array(h['hand_xyz_m']),'R':quat(h['hand_quaternion_wxyz']), 'points':np.concatenate([edges,points]),'edge_count':len(edges),'camera':{'origin':np.array(cam['camera_world_xyz_m']),'rotation':np.array(cam['world_to_camera_rotation']),'focal':np.array(cam['focal_xy_px']),'principal':np.array(cam['principal_xy_px'])}}

def fit(frames):
 def residual(p):return np.r_[np.concatenate([residual_frame(p,f)/np.sqrt(len(f['points'])) for f in frames]),max(0,np.linalg.norm(p[:3])-.13)*1000]
 rng=np.random.default_rng(1);answers=[];steps=np.array([1e-4]*3+[1e-3]*3)
 for start in range(20):
  p=np.r_[np.zeros(3),np.zeros(3) if start==0 else rng.uniform(-np.pi,np.pi,3)];r=residual(p);score=r@r;damping=1.
  for _ in range(55):
   J=np.column_stack([(residual(p+np.eye(6)[j]*steps[j])-r)/steps[j] for j in range(6)])
   try:delta=np.linalg.solve(J.T@J+damping*np.diag(np.maximum((J*J).sum(axis=0),1)), -J.T@r)
   except np.linalg.LinAlgError:break
   delta[:3]=np.clip(delta[:3],-.03,.03);delta[3:]=np.clip(delta[3:],-.3,.3)
   candidate=p+delta;rr=residual(candidate);ss=rr@rr
   if ss<score:
    p,r,score=candidate,rr,ss;damping=max(damping/2,1e-5)
    if np.linalg.norm(delta)<1e-6:break
   else:damping=min(damping*5,1e8)
  if np.linalg.norm(p[:3])>.13:continue
  rms=[float(np.sqrt(np.mean(residual_frame(p,f)**2))) for f in frames]
  answers.append({'center_xyz_m':(frames[-1]['hand']+frames[-1]['R']@p[:3]).tolist(),'rms_px':max(rms),'frame_rms':rms,'offset':p[:3].tolist()})
 return sorted(answers,key=lambda x:x['rms_px'])
if __name__=='__main__':
 import json
 from pathlib import Path
 from humanoid_sim.carried_pose import select_hypotheses
 for path in sorted(Path('runtime/humanoid/carried-development').glob('*/records.json')):
  records=json.loads(path.read_text());frames=[]
  for index in [4,5,6,7,8,9]:
   record=records[index];f=prepare((path.parent/record['image']).read_bytes(),record['observation'])
   if f is None:frames=[];continue
   frames.append(f);frames=frames[-3:]
   if len(frames)<2 or max(np.linalg.norm(a['hand']-b['hand']) for a in frames for b in frames)<.08:continue
   a=fit(frames);res=select_hypotheses(a);error=np.linalg.norm(np.array(res['object_center_xyz_m'])-record['private_truth_xyz'])*1000 if res['detected'] else None
   print(path.parent.name,index,res,error,'best',a[:1],flush=True)

import base64,hashlib,json
from pathlib import Path
import numpy as np
from humanoid_sim.carried_pose import estimate_carried_block
root=Path('runtime/humanoid/temporal-P4');capture=json.loads((root/'capture/summary.json').read_text());rows=[]
output=root/'single_frame_comparison.json'
assert not output.exists()
for episode in capture['episodes']:
 for index,frame in enumerate(episode['frames']):
  if frame['stage'] not in ['lift','lift_hold','transport','lower']:continue
  for name,sha in capture['source_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
  observation=json.loads((root/'capture'/f"seed-{episode['seed']}"/f'{index:02d}-observation.json').read_text())
  estimate=estimate_carried_block(base64.b64decode(observation['rgb_png_base64']),observation['camera'],observation['robot_state']['robot']['hand_xyz_m'])
  error=float(np.linalg.norm(np.array(estimate['object_center_xyz_m'])-frame['private_true_xyz_m'])) if estimate['detected'] else None
  rows.append({'seed':episode['seed'],'stage':frame['stage'],'estimate':estimate,'error_3d_m':error,'within_20mm':error is not None and error<=.02})
  output.write_text(json.dumps({'status':'running','post_hoc':True,'method':'unchanged_P3_on_P4_original_frames','records':rows},indent=2)+'\n')
output.write_text(json.dumps({'status':'complete','post_hoc':True,'method':'unchanged_P3_on_P4_original_frames','source_sha256':capture['source_sha256'],'records':rows},indent=2)+'\n')
print('Completed paired single-frame diagnostic:',len(rows),flush=True)

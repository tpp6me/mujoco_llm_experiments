from pathlib import Path
import base64,itertools,json
import mujoco,numpy as np
from humanoid_sim.environment import Environment
from humanoid_sim.visual import RGBRenderer,VisualSession,integration_state,detect_red_pixels,project,pixel_to_plane
root=Path('runtime/humanoid/visual-v1/validation');root.mkdir(exist_ok=False)
env=Environment();renderer=RGBRenderer(env);records=[]
try:
 for seed in range(700,705):
  env.reset(seed,True);s=VisualSession(env,renderer);before=integration_state(env);o=s.capture()
  np.testing.assert_array_equal(integration_state(env),before)
  png=base64.b64decode(o['rgb_png_base64']);(root/f'seed-{seed}.png').write_bytes(png)
  d=detect_red_pixels(png);assert d['detected']
  geom=env.object_geom;center=env.data.geom_xpos[geom];rot=env.data.geom_xmat[geom].reshape(3,3)
  points=[center+rot@(np.asarray(signs)*env.model.geom_size[geom]) for signs in itertools.product([-1,1],repeat=3)]
  pixels=np.asarray([project(p,o['camera']) for p in points]); bounds=np.r_[pixels.min(axis=0),pixels.max(axis=0)]
  box=np.asarray(d['bbox_xyxy_px']);assert np.all(box[:2]>=bounds[:2]-2) and np.all(box[2:]<=bounds[2:]+2),(seed,box,bounds)
  estimate=pixel_to_plane(d['centroid_xy_px'],.82,o['camera'])
  records.append({'seed':seed,'state_unchanged':True,'rendered_red_bbox_px':box.tolist(),'projected_geom_bbox_px':bounds.tolist(),
                  'pixel_detection':d,'known_top_plane_estimate_xyz':estimate,'private_true_center_xyz':center.tolist(),
                  'xy_error_m':float(np.linalg.norm(np.asarray(estimate[:2])-center[:2]))})
finally:renderer.close()
(root/'private_validation.json').write_text(json.dumps({'development_only':True,'camera':'fixed','records':records},indent=2)+'\n')
print(json.dumps({'captures':len(records),'max_xy_detection_error_m':max(r['xy_error_m'] for r in records),'state_preservation':'all exact','projection_bbox_check':'all pass'},indent=2))

import io,itertools,json
from pathlib import Path
import numpy as np
from PIL import Image
exec(open('/private/tmp/cuboid-prototype.py').read().split('def quad')[0])
CORNERS=np.array(list(itertools.product([-1,1],repeat=3)))*[.025,.035,.06]
def rotation(v):
 theta=np.linalg.norm(v)
 if theta<1e-12:return np.eye(3)
 x,y,z=v/theta;K=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
 return np.eye(3)+np.sin(theta)*K+(1-np.cos(theta))*(K@K)
def features(png):
 rgb=np.array(Image.open(io.BytesIO(png)).convert('RGB'),dtype=float);r,g,b=rgb.transpose(2,0,1)
 red=(r>65)&(r>1.8*g)&(r>1.8*b)
 # Robot is neutral gray/white. Background/table/basket are chromatic.
 background=(((g>1.4*r)&(b>1.4*r))|((r>1.3*b)&(g>1.3*b)&(g>80))|np.all(abs(rgb-[82,99,119])<3,axis=2))&~red
 nearby=np.zeros(red.shape,dtype=bool)
 for dy,dx in [(-1,0),(1,0),(0,-1),(0,1)]:nearby|=np.roll(background,(dy,dx),(0,1))
 edge=np.argwhere(red&nearby)[:,::-1].astype(float)
 interior=np.argwhere(red)[:,::-1].astype(float)
 return edge[::max(1,len(edge)//150)],interior[::max(1,len(interior)//200)]
def fit(png,cam,hand,starts=20):
 edges,points=features(png)
 if len(edges)<30:return []
 Rcam=np.array(cam['world_to_camera_rotation']);origin=np.array(cam['camera_world_xyz_m']);focal=np.array(cam['focal_xy_px']);principal=np.array(cam['principal_xy_px'])
 def residual(params):
  world=CORNERS@rotation(params[3:]).T+params[:3]
  local=(world-origin)@Rcam.T
  uv=local[:,:2]/np.maximum(local[:,2,None],.01)*focal+principal
  poly=hull(uv);a=poly;b=np.roll(poly,-1,axis=0);d=b-a;length=np.linalg.norm(d,axis=1)
  allpoints=np.concatenate([edges,points]);v=allpoints[:,None,:]-a
  t=np.clip(np.sum(v*d,axis=2)/length**2,0,1)
  distance=np.linalg.norm(v-t[:,:,None]*d,axis=2).min(axis=1)
  inside=np.all(d[:,0]*v[:,:,1]-d[:,1]*v[:,:,0]>=0,axis=1)
  result=np.r_[distance[:len(edges)],np.where(inside[len(edges):],0,distance[len(edges):])*2]
  # Explicit proximity prior only; no true object state or support plane.
  prior=max(0,np.linalg.norm(params[:3]-hand)-.13)*1000
  return np.r_[result,prior]
 rng=np.random.default_rng(1);answers=[]
 for i in range(starts):
  p=np.r_[hand,np.zeros(3) if i==0 else rng.uniform(-np.pi,np.pi,3)]
  damping=1.;r=residual(p);score=r@r
  for iteration in range(55):
   steps=np.array([1e-4]*3+[1e-3]*3)
   J=np.column_stack([(residual(p+np.eye(6)[j]*steps[j])-r)/steps[j] for j in range(6)])
   try:delta=np.linalg.solve(J.T@J+damping*np.diag(np.maximum((J*J).sum(axis=0),1)), -J.T@r)
   except np.linalg.LinAlgError:break
   delta[:3]=np.clip(delta[:3],-.03,.03);delta[3:]=np.clip(delta[3:],-.3,.3)
   candidate=p+delta;rr=residual(candidate);ss=rr@rr
   if ss<score:
    p,r,score=candidate,rr,ss;damping=max(damping/2,1e-5)
    if np.linalg.norm(delta)<1e-6:break
   else:damping=min(damping*5,1e8)
  answers.append({'xyz':p[:3].tolist(),'rotation':rotation(p[3:]).tolist(),'score':float(np.sqrt(score/len(r)))})
 return sorted(answers,key=lambda x:x['score'])
if __name__=='__main__':
 for p in sorted(Path('runtime/humanoid/carried-development').glob('*/records.json')):
  for record in json.loads(p.read_text()):
   if record['image'] not in ['04.png','06.png']:continue
   o=record['observation'];hand=o['robot_state']['robot']['hand_xyz_m']
   answers=fit((p.parent/record['image']).read_bytes(),o['camera'],hand)
   print(p.parent.name,record['image'],[(round(np.linalg.norm(np.array(a['xyz'])-record['private_truth_xyz'])*1000,1),round(a['score'],2)) for a in answers[:5]],flush=True)

import io,itertools,math
from collections import deque
import numpy as np
from PIL import Image


def hull(points):
 points=sorted(set(map(tuple,points)))
 def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lower=[];upper=[]
 for p in points:
  while len(lower)>1 and cross(lower[-2],lower[-1],p)<=0:lower.pop()
  lower.append(p)
 for p in reversed(points):
  while len(upper)>1 and cross(upper[-2],upper[-1],p)<=0:upper.pop()
  upper.append(p)
 return np.array(lower[:-1]+upper[:-1],dtype=float)

def largest(points):
 remaining=set(map(tuple,points));components=[]
 while remaining:
  queue=deque([remaining.pop()]);part=[]
  while queue:
   x,y=queue.popleft();part.append((x,y))
   for n in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
    if n in remaining:remaining.remove(n);queue.append(n)
  components.append(part)
 return np.array(max(components,key=len))

def area(p):return abs(np.sum(p[:,0]*np.roll(p[:,1],-1)-p[:,1]*np.roll(p[:,0],-1)))/2

def quad(points):
 original=hull(points)
 p=original.copy()
 while len(p)>4:
  losses=[area(p[[(i-1)%len(p),i,(i+1)%len(p)]]) for i in range(len(p))]
  p=np.delete(p,np.argmin(losses),axis=0)
 if len(p)!=4 or area(p)<150:return None
 if area(p)/area(original)<.85:return None
 # Expand center-of-pixel hull to outer pixel boundaries along each edge.
 normals=[];offsets=[]
 for a,b in zip(p,np.roll(p,-1,axis=0)):
  edge=b-a;n=np.array([edge[1],-edge[0]])/np.linalg.norm(edge)
  normals.append(n);offsets.append(np.dot(n,a)+.5)
 normals=np.array(normals);offsets=np.array(offsets)
 try:return np.array([np.linalg.solve(normals[[i-1,i]],offsets[[i-1,i]]) for i in range(4)])
 except np.linalg.LinAlgError:return None

def project(points,cam):
 q=(points-np.array(cam['camera_world_xyz_m']))@np.array(cam['world_to_camera_rotation']).T
 return q[:,:2]/q[:,2,None]*cam['focal_xy_px']+cam['principal_xy_px']

def candidates(png,cam,hand):
 rgb=np.array(Image.open(io.BytesIO(png)).convert('RGB'),dtype=float);r,g,b=rgb.transpose(2,0,1);red=(r>65)&(r>1.8*g)&(r>1.8*b)
 coords=np.argwhere(red)[:,::-1]; vals,counts=np.unique(r[red],return_counts=True)
 levels=vals[np.argsort(counts)[-8:]]
 answers=[]
 for value in levels:
  points=np.argwhere(red&(abs(r-value)<=1))[:,::-1]
  if len(points)<200:continue
  points=largest(points)
  q=quad(points)
  if q is None or len(points)/area(q)<.8:continue
  norm=(q-cam['principal_xy_px'])/cam['focal_xy_px']
  for dims in [(a,b,c) for a,b,c in itertools.permutations([.05,.07,.12])]:
   a,b,c=dims;xy=np.array([[-a/2,-b/2],[a/2,-b/2],[a/2,b/2],[-a/2,b/2]])
   A=[];rhs=[]
   for (x,y),(u,v) in zip(xy,norm):
    A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);rhs.extend([u,v])
   H=np.r_[np.linalg.solve(A,rhs),1].reshape(3,3)
   scale=2/(np.linalg.norm(H[:,0])+np.linalg.norm(H[:,1]));H*=scale
   R=np.column_stack([H[:,0],H[:,1],np.cross(H[:,0],H[:,1])]);u,_,v=np.linalg.svd(R);R=u@v
   t=H[:,2];normal=R[:,2]
   if normal@t>0:normal=-normal
   center=t-normal*c/2
   wc=np.array(cam['camera_world_xyz_m'])+np.array(cam['world_to_camera_rotation']).T@center
   if np.linalg.norm(wc-hand)>.13:continue
   recon=(xy@R[:,:2].T+t);recon=recon[:,:2]/recon[:,2,None]*cam['focal_xy_px']+cam['principal_xy_px']
   residual=np.sqrt(np.mean(np.sum((recon-q)**2,axis=1)))
   if residual>2:continue
   corners=np.array([t+R[:,0]*sx*a/2+R[:,1]*sy*b/2+normal*sz*c for sx,sy,sz in itertools.product([-1,1],[-1,1],[-1,0])])
   pp=corners[:,:2]/corners[:,2,None]*cam['focal_xy_px']+cam['principal_xy_px'];poly=hull(pp)
   vectors=np.roll(poly,-1,axis=0)-poly
   cross=vectors[:,0,None]*(coords[None,:,1]-poly[:,None,1])-vectors[:,1,None]*(coords[None,:,0]-poly[:,None,0])
   inside=np.all(cross>=-np.linalg.norm(vectors,axis=1)[:,None]*2,axis=0).mean()
   coverage=len(coords)/area(poly)
   if inside<.98 or not .5<coverage<1.08:continue
   answers.append({'xyz':wc.tolist(),'residual':float(residual),'inside':float(inside),'coverage':float(coverage),'level':float(value),'dims':dims})
 return answers

if __name__=='__main__':
 import json
 from pathlib import Path
 for p in sorted(Path('runtime/humanoid/carried-development').glob('*/records.json')):
  for record in json.loads(p.read_text()):
   if record['image'] not in ['04.png','05.png','06.png','07.png']:continue
   o=record['observation'];hand=o['robot_state']['robot']['hand_xyz_m']
   answers=candidates((p.parent/record['image']).read_bytes(),o['camera'],hand)
   print(p.parent.name,record['image'],len(answers),[(round(np.linalg.norm(np.array(a['xyz'])-record['private_truth_xyz'])*1000,1),round(a['residual'],2),a['dims'],a['level']) for a in answers])

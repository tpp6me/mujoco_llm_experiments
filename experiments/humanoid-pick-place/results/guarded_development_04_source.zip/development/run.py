import json
from pathlib import Path
from humanoid_sim.environment import Environment
from humanoid_sim.interface import PolicyInterface
from humanoid_sim.guarded_baseline import run_policy
folder=Path('runtime/humanoid/guarded-development-04');folder.mkdir(exist_ok=False)
reports=[]
seeds=[0,300,312,352,357,358,365,373,393,401,403,482,483,301,302,303,304,305,306,307]
previous=json.loads(Path('runtime/humanoid/guarded-g1-100/summary.json').read_text())
assert previous['status']=='complete'
seeds+= [r['seed'] for r in previous['reports'] if not r['gate_success']]
for seed in seeds:
 env=Environment();env.reset(seed,True);error=None
 try:error=run_policy(PolicyInterface(env), release_z=.88)
 except (ValueError,RuntimeError) as exc:error=str(exc)
 r={'seed':seed,**env.scorer.report(),'error':error,'time_s':float(env.data.time)}
 r['gate_success']=r['success'] and r['max_object_penetration_m']<=.002 and error is None and env.data.time<=25.000001
 env.save(folder/f'seed-{seed:04}');reports.append(r)
 (folder/'summary.json').write_text(json.dumps({'development_only':True,'reports':reports},indent=2)+'\n')
 print(json.dumps(r),flush=True)

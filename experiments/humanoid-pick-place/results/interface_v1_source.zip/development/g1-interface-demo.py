import hashlib
import json
from pathlib import Path
from humanoid_sim.environment import Environment, DOWNWARD
from humanoid_sim.interface import PolicyInterface, VERSION, quaternion
from humanoid_sim.baseline import run_baseline, release_target

folder = Path('runtime/humanoid/interface-development/nominal')
if folder.exists(): raise ValueError('Development episode already exists')
env = Environment(); api = PolicyInterface(env)
class Policy:
    scorer = env.scorer
    def observe(self): return api.observe()['task_state']
    def send(self, action, args):
        result = api.execute(dict(schema_version=VERSION, instruction_version=1,
                                 request_id=str(len(env.events)), action=action, arguments=args))
        if result['status'] != 'completed': raise RuntimeError(result['error'])
    def move(self, xyz, seconds=2): self.send('move', dict(xyz_m=list(xyz), quaternion_wxyz=quaternion(DOWNWARD), seconds=seconds))
    def hand(self, closure, seconds=2): self.send('hand', dict(closure=closure, seconds=seconds))
    def hold(self, seconds=2): self.send('hold', dict(seconds=seconds))
policy=Policy()
try: run_baseline(policy)
except RuntimeError as exc:
    assert 'penetration' in str(exc) and abs(env.data.time-11)<1e-6
    target=release_target(policy.observe()); target[2]=.90
    policy.move(target);policy.hand(0)
    policy.move([target[0],target[1],.975]);policy.move([.24,-.18,.975]);policy.hold(6)
else: raise AssertionError('Expected development rejection was not reproduced')
env.save(folder)
report={'development_only':True,'seed':0,'randomized':False,'controller':'conventional_exact_state_guarded_explicit_recovery',
        **env.scorer.report(),'time_s':float(env.data.time),'rejected_actions':sum(e['interface_response']['status']=='rejected' for e in env.events),
        'source_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path('humanoid_sim').glob('*.py'))}}
assert report['success'] and report['max_object_penetration_m']<=.002
(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n')
Path('experiments/humanoid-pick-place/results/interface_v1_development.json').write_text(json.dumps({'report':report,'events':env.events},indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'},indent=2))

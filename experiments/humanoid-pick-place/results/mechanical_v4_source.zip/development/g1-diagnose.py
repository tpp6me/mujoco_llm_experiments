import json
from pathlib import Path
import numpy as np
import mujoco
from humanoid_sim.environment import Environment
from humanoid_sim.baseline import run_baseline
for seed in [312,352,365,373,300,357,358,393]:
 e=Environment();e.reset(seed,True);peaks=[];stages=[];original=e.scorer.update
 def update(data):
  before=e.scorer.max_penetration;original(data)
  if e.scorer.max_penetration>before and e.scorer.max_penetration>.001:
   cs=[(i,c) for i,c in enumerate(data.contact) if e.object_geom in (c.geom1,c.geom2)]
   i,c=min(cs,key=lambda pair:pair[1].dist);force=np.zeros(6);mujoco.mj_contactForce(e.model,data,i,force)
   other=c.geom2 if c.geom1==e.object_geom else c.geom1
   peaks.append({'time':float(data.time),'dist':float(c.dist),'other':e.model.body(e.model.geom_bodyid[other]).name,'geom_type':int(e.model.geom_type[other]),'force':force.tolist(),'hand_q':data.qpos[e.act_q[e.hand_a]].tolist(),'object_q':data.qpos[-7:].tolist(),'object_v':data.qvel[-6:].tolist()})
 e.scorer.update=update
 for name in ['move','hand','hold']:
  original_action=getattr(e,name)
  def wrapped(*args,_name=name,_fn=original_action,**kwargs):
   r=_fn(*args,**kwargs);stages.append({'action':_name,'args':args,'time':e.data.time,'score':e.scorer.report(),'observation':e.observe()});return r
  setattr(e,name,wrapped)
 err=run_baseline(e)
 Path(f'runtime/humanoid/contact-diagnosis/{seed}.json').write_text(json.dumps({'seed':seed,'error':err,'peaks':peaks,'stages':stages},indent=2))
 print(seed,err,[(x['action'],round(x['time'],1),round(x['score']['max_object_penetration_m']*1000,2)) for x in stages], 'worst',peaks[-1] if peaks else None,flush=True)

import json,numpy as np
from pathlib import Path
from humanoid_sim.environment import Environment
SEEDS=[312,352,365,373,300,357,358,393,301,302]
results=[]
for center,z in [(False,.86),(True,.86),(True,.90),(True,.92)]:
 for seed in SEEDS:
  e=Environment();e.reset(seed,True);x,y,_=e.observe()['object_xyz'];x+=.015;error=None
  try:
   e.move([x,y,.975]);e.move([x,y,.775]);e.hand(1);e.move([x,y,.975]);e.hold(.5);e.move([.19,-.36,.975])
   o=e.observe();target=np.array([.19,-.36,z])
   if center:target[:2]=np.array([.18,-.36])+np.array(o['hand_xyz'])[:2]-np.array(o['object_xyz'])[:2]
   e.move(target.tolist());e.hand(0);e.move([target[0],target[1],.975]);e.move([.24,-.18,.975]);e.hold(6)
  except ValueError as exc:error=str(exc)
  r={'seed':seed,'center':center,'z':z,'error':error,**e.scorer.report()};results.append(r)
  print(center,z,seed,r['success'],round(r['max_object_penetration_m']*1000,3),error,flush=True)
Path('runtime/humanoid/contact-diagnosis/release-probes.json').write_text(json.dumps(results,indent=2))

import json,numpy as np
from pathlib import Path
from humanoid_sim.environment import Environment
from humanoid_sim.scene import TABLE_Z
results=[]
for cap in [.235,.24]:
 for seed in [312,352,365,373,300,357,358,393,301,302,303,304]:
  e=Environment();e.reset(seed,True);x,y,_=e.observe()['object_xyz'];x+=.015;error=None
  try:
   e.move([x,y,.975]);e.move([x,y,TABLE_Z+.075]);e.hand(1);e.move([x,y,.975]);e.hold(.5);e.move([.19,-.36,.975])
   o=e.observe();target=np.r_[np.array([.18,-.36])+np.array(o['hand_xyz'])[:2]-np.array(o['object_xyz'])[:2],.86]
   target[0]=min(cap,target[0])
   e.move(target.tolist());e.hand(0);e.move([target[0],target[1],.975]);e.move([.24,-.18,.975]);e.hold(6)
  except ValueError as exc:error=str(exc)
  r={'seed':seed,'cap':cap,'error':error,**e.scorer.report(),'final':e.observe()};results.append(r)
  print(cap,seed,r['success'],round(r['max_object_penetration_m']*1000,3),error,flush=True)
Path('runtime/humanoid/contact-diagnosis/centered-probes.json').write_text(json.dumps(results,indent=2))
